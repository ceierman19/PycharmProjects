# Carrie Eierman
# Section 6.4 (p. 230-231)
# Top-Down (Max) Heap Construction

import math

def sift_up(array, end):
    # end is the node to sift up
    child = end
    while child > 0:
        parent = math.floor(child/2)  # parents are in the first half of array
        if array[parent] < array[child]:  # if out of max-heap order, swap
            array[parent], array[child] = array[child], array[parent]
            child = parent  # compare node with new parent
        else:
            break  # terminates loop

def heapify(array, count):
    array.insert(0, 100)  # sentinel
    end = 1  # end is assigned the index of the first/left child of the root
    while end < count:
        sift_up(array, end)
        end = end + 1
        print(array)
    # after sifting up the last node, all nodes are in heap order

# Figure 6.12 (p. 230)
array = [2, 9, 7, 6, 5, 8, 10]
count = len(array) + 1
heapify(array, count)

# Figure 6.10 (p. 228) inverted, contains repeating values
array = [1, 5, 3, 6, 1, 2, 5, 7, 8, 10]
count = len(array) + 1
heapify(array, count)

# Increasing values
array = [1, 2, 3, 4, 5]
count = len(array) + 1
heapify(array, count)

# Longer array, no repeating values
array = [1, 3, 5, 4, 6, 13, 10, 9, 8, 15, 17, 7, 2, 88, 11]
count = len(array) + 1
heapify(array, count)
